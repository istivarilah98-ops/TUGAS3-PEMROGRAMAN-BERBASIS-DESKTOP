
import java.io.File;
import java.util.Scanner;

public class Main {

    private static final String FILE_MENU = "menu.txt";
    private static final String FILE_STRUK = "struk.txt";

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Menu menu = new Menu();
        Pesanan pesanan = new Pesanan();

        // Memuat menu dari file
        File fileMenu = new File(FILE_MENU);

        if (fileMenu.exists()) {
            menu.muatMenu(FILE_MENU);
        } else {
            isiMenuAwal(menu);
            menu.simpanMenu(FILE_MENU);
        }

        int pilihan;

        do {
            tampilkanMenuUtama();
            pilihan = bacaAngka(input, "Pilih menu: ");

            switch (pilihan) {

                case 1:
                    tambahItemMenu(input, menu);
                    break;

                case 2:
                    menu.tampilkanMenu();
                    break;

                case 3:
                    buatPesanan(input, menu, pesanan);
                    break;

                case 4:
                    if (pesanan.isKosong()) {
                        System.out.println("Belum ada pesanan.");
                    } else {
                        System.out.printf("Total pembayaran: Rp%.0f%n",
                                pesanan.hitungTotal(menu));
                    }
                    break;

                case 5:
                    pesanan.tampilkanStruk(menu);
                    break;

                case 6:
                    menu.simpanMenu(FILE_MENU);
                    break;

                case 7:
                    menu.muatMenu(FILE_MENU);
                    menu.tampilkanMenu();
                    break;

                case 8:
                    pesanan.simpanStruk(FILE_STRUK, menu);
                    break;

                case 9:
                    pesanan.tampilkanRiwayatStruk(FILE_STRUK);
                    break;

                case 0:
                    System.out.println(
                            "Terima kasih telah menggunakan Aplikasi Resto UT.");
                    break;

                default:
                    System.out.println(
                            "Pilihan tidak tersedia. Silakan pilih kembali.");
            }

        } while (pilihan != 0);

        input.close();
    }

    // Menampilkan menu utama
    private static void tampilkanMenuUtama() {
        System.out.println("\n========================================");
        System.out.println("       APLIKASI RESTO UT");
        System.out.println("========================================");
        System.out.println("1. Tambah Item Menu");
        System.out.println("2. Tampilkan Daftar Menu");
        System.out.println("3. Buat Pesanan");
        System.out.println("4. Hitung Total Pesanan");
        System.out.println("5. Tampilkan Struk");
        System.out.println("6. Simpan Menu ke File");
        System.out.println("7. Muat Menu dari File");
        System.out.println("8. Simpan Struk ke File");
        System.out.println("9. Lihat Riwayat Struk");
        System.out.println("0. Keluar");
        System.out.println("========================================");
    }

    // Mengisi menu awal
    private static void isiMenuAwal(Menu menu) {
        menu.tambahItem(new Makanan(
                "Nasi Goreng", 15000, "Makanan", "Makanan Berat"));

        menu.tambahItem(new Makanan(
                "Mie Goreng", 13000, "Makanan", "Makanan Berat"));

        menu.tambahItem(new Makanan(
                "Ayam Geprek", 18000, "Makanan", "Makanan Berat"));

        menu.tambahItem(new Minuman(
                "Es Teh", 5000, "Minuman", "Minuman Dingin"));

        menu.tambahItem(new Minuman(
                "Jus Jeruk", 8000, "Minuman", "Minuman Dingin"));

        menu.tambahItem(new Minuman(
                "Kopi", 7000, "Minuman", "Minuman Panas"));

        menu.tambahItem(new Diskon("Diskon Pelanggan", 10));
    }

    // Menambahkan item menu
    private static void tambahItemMenu(Scanner input, Menu menu) {
        System.out.println("\n--- TAMBAH ITEM MENU ---");
        System.out.println("1. Makanan");
        System.out.println("2. Minuman");
        System.out.println("3. Diskon");

        int jenis = bacaAngka(input, "Pilih jenis item: ");

        if (jenis == 1 || jenis == 2) {

            System.out.print("Nama: ");
            String nama = input.nextLine();

            double harga = bacaDesimal(input, "Harga: ");

            System.out.print("Kategori: ");
            String kategori = input.nextLine();

            if (jenis == 1) {
                System.out.print("Jenis makanan: ");
                String jenisMakanan = input.nextLine();

                menu.tambahItem(new Makanan(
                        nama, harga, kategori, jenisMakanan));

            } else {
                System.out.print("Jenis minuman: ");
                String jenisMinuman = input.nextLine();

                menu.tambahItem(new Minuman(
                        nama, harga, kategori, jenisMinuman));
            }

            System.out.println(
                    "Item berhasil ditambahkan. Simpan menu agar perubahan tersimpan.");

        } else if (jenis == 3) {

            System.out.print("Nama diskon: ");
            String nama = input.nextLine();

            double diskon = bacaDesimal(
                    input, "Persentase diskon (0-100): ");

            if (diskon < 0 || diskon > 100) {
                System.out.println(
                        "Persentase diskon harus antara 0 sampai 100.");
                return;
            }

            menu.tambahItem(new Diskon(nama, diskon));

            System.out.println(
                    "Diskon berhasil ditambahkan. Simpan menu agar perubahan tersimpan.");

        } else {
            System.out.println("Jenis item tidak tersedia.");
        }
    }

    // Membuat pesanan
    private static void buatPesanan(
            Scanner input, Menu menu, Pesanan pesanan) {

        if (menu.getDaftarMenu().isEmpty()) {
            System.out.println("Menu restoran masih kosong.");
            return;
        }

        String lanjut;

        do {
            menu.tampilkanMenu();

            int nomor = bacaAngka(
                    input, "Masukkan nomor makanan/minuman (0 untuk selesai): ");

            if (nomor == 0) {
                break;
            }

            try {
                MenuItem item = menu.cariItem(nomor);

                if (item instanceof Diskon) {
                    System.out.println(
                            "Item diskon tidak dapat dipesan. Diskon diterapkan saat menghitung total.");

                } else {
                    int jumlah = bacaAngka(
                            input, "Jumlah pesanan: ");

                    pesanan.tambahPesanan(item, jumlah);
                }

            } catch (IndexOutOfBoundsException
                    | IllegalArgumentException e) {

                System.out.println(
                        "Pesanan tidak dapat diproses: " + e.getMessage());
            }

            System.out.print("Tambah pesanan lain? (y/n): ");
            lanjut = input.nextLine();

        } while (lanjut.equalsIgnoreCase("y"));
    }

    // Membaca input angka bulat
    private static int bacaAngka(Scanner input, String pesan) {
        while (true) {
            System.out.print(pesan);
            String teks = input.nextLine();

            try {
                return Integer.parseInt(teks);

            } catch (NumberFormatException e) {
                System.out.println("Masukkan angka yang benar.");
            }
        }
    }

    // Membaca input angka desimal
    private static double bacaDesimal(
            Scanner input, String pesan) {

        while (true) {
            System.out.print(pesan);
            String teks = input.nextLine().replace(",", ".");

            try {
                double angka = Double.parseDouble(teks);

                if (angka < 0) {
                    System.out.println("Nilai tidak boleh negatif.");
                } else {
                    return angka;
                }

            } catch (NumberFormatException e) {
                System.out.println("Masukkan angka yang benar.");
            }
        }
    }
}
