
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

public class Menu {

    private ArrayList<MenuItem> daftarMenu;

    public Menu() {
        daftarMenu = new ArrayList<>();
    }

    // Menambahkan item menu
    public void tambahItem(MenuItem item) {
        daftarMenu.add(item);
    }

    // Mengambil daftar menu
    public ArrayList<MenuItem> getDaftarMenu() {
        return daftarMenu;
    }

    // Mencari menu berdasarkan nomor
    public MenuItem cariItem(int nomor) {
        if (nomor < 1 || nomor > daftarMenu.size()) {
            throw new IndexOutOfBoundsException(
                    "Nomor menu tidak ditemukan!");
        }

        return daftarMenu.get(nomor - 1);
    }

    // Menampilkan daftar menu
    public void tampilkanMenu() {
        System.out.println("==================================================");
        System.out.println("                  APLIKASI RESTO UT");
        System.out.println("                     DAFTAR MENU");
        System.out.println("==================================================");

        System.out.printf("%-5s %-20s %-12s %-15s%n",
                "No", "Nama Menu", "Kategori", "Harga");

        System.out.println("--------------------------------------------------");

        int nomor = 1;

        for (MenuItem item : daftarMenu) {
            if (!(item instanceof Diskon)) {
                System.out.printf("%-5d %-20s %-12s Rp%-12.0f%n",
                        nomor,
                        item.getNama(),
                        item.getKategori(),
                        item.getHarga());

                nomor++;
            }
        }

        System.out.println("--------------------------------------------------");
        System.out.println("PROMO DISKON");

        for (MenuItem item : daftarMenu) {
            if (item instanceof Diskon) {
                Diskon diskon = (Diskon) item;

                System.out.println(item.getNama() + " : "
                        + diskon.getDiskon() + "%");
            }
        }

        System.out.println("==================================================");
    }

    // Menyimpan menu ke file
    public void simpanMenu(String namaFile) {
        try (PrintWriter output = new PrintWriter(
                new FileWriter(namaFile))) {

            for (MenuItem item : daftarMenu) {

                if (item instanceof Makanan) {
                    Makanan makanan = (Makanan) item;

                    output.println("MAKANAN|" + makanan.getNama() + "|"
                            + makanan.getHarga() + "|"
                            + makanan.getKategori() + "|"
                            + makanan.getJenisMakanan());

                } else if (item instanceof Minuman) {
                    Minuman minuman = (Minuman) item;

                    output.println("MINUMAN|" + minuman.getNama() + "|"
                            + minuman.getHarga() + "|"
                            + minuman.getKategori() + "|"
                            + minuman.getJenisMinuman());

                } else if (item instanceof Diskon) {
                    Diskon diskon = (Diskon) item;

                    output.println("DISKON|" + diskon.getNama()
                            + "|0|Diskon|"
                            + diskon.getDiskon());
                }
            }

            System.out.println("Menu berhasil disimpan ke file.");

        } catch (IOException e) {
            System.out.println("Gagal menyimpan menu: "
                    + e.getMessage());
        }
    }

    // Memuat menu dari file
    public void muatMenu(String namaFile) {
        ArrayList<MenuItem> menuSementara = new ArrayList<>();

        try (BufferedReader input = new BufferedReader(
                new FileReader(namaFile))) {

            String baris;

            while ((baris = input.readLine()) != null) {
                String[] data = baris.split("\\|");

                if (data.length == 5) {
                    String tipe = data[0];
                    String nama = data[1];
                    double harga = Double.parseDouble(data[2]);
                    String kategori = data[3];

                    if (tipe.equals("MAKANAN")) {

                        menuSementara.add(new Makanan(
                                nama, harga, kategori, data[4]));

                    } else if (tipe.equals("MINUMAN")) {

                        menuSementara.add(new Minuman(
                                nama, harga, kategori, data[4]));

                    } else if (tipe.equals("DISKON")) {

                        double nilaiDiskon =
                                Double.parseDouble(data[4]);

                        menuSementara.add(new Diskon(
                                nama, nilaiDiskon));
                    }
                }
            }

            daftarMenu.clear();
            daftarMenu.addAll(menuSementara);

            System.out.println("Menu berhasil dimuat dari file.");

        } catch (IOException e) {
            System.out.println("Gagal memuat menu: "
                    + e.getMessage());

        } catch (NumberFormatException e) {
            System.out.println("Format data menu tidak valid.");
        }
    }
}
