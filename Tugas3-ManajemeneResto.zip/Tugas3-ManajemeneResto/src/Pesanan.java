import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

public class Pesanan {
    private ArrayList<MenuItem> daftarPesanan;
    private ArrayList<Integer> jumlahPesanan;

    public Pesanan() {
        daftarPesanan = new ArrayList<>();
        jumlahPesanan = new ArrayList<>();
    }

    public boolean isKosong() {
        return daftarPesanan.isEmpty();
    }

    public void tambahPesanan(MenuItem item, int jumlah) {
        if (item instanceof Diskon) {
            throw new IllegalArgumentException("Diskon tidak dapat dipesan sebagai makanan/minuman.");
        }
        if (jumlah <= 0) {
            throw new IllegalArgumentException("Jumlah pesanan harus lebih dari 0.");
        }

        daftarPesanan.add(item);
        jumlahPesanan.add(jumlah);
        System.out.println(item.getNama() + " berhasil ditambahkan ke pesanan.");
    }

    private double hitungSubtotal() {
        double subtotal = 0;
        for (int i = 0; i < daftarPesanan.size(); i++) {
            subtotal += daftarPesanan.get(i).getHarga() * jumlahPesanan.get(i);
        }
        return subtotal;
    }

    private Diskon cariDiskon(Menu menu) {
        Diskon diskonTerbesar = null;

        for (MenuItem item : menu.getDaftarMenu()) {
            if (item instanceof Diskon) {
                Diskon diskon = (Diskon) item;
                if (diskonTerbesar == null || diskon.getDiskon() > diskonTerbesar.getDiskon()) {
                    diskonTerbesar = diskon;
                }
            }
        }
        return diskonTerbesar;
    }

    public double hitungTotal(Menu menu) {
        double subtotal = hitungSubtotal();
        Diskon diskon = cariDiskon(menu);

        if (diskon != null) {
            return subtotal - (subtotal * diskon.getDiskon() / 100);
        }
        return subtotal;
    }

    public void tampilkanStruk(Menu menu) {
        if (isKosong()) {
            System.out.println("Belum ada pesanan.");
            return;
        }

        double subtotal = hitungSubtotal();
        Diskon diskon = cariDiskon(menu);
        double potongan = 0;

        System.out.println("\n========================================");
        System.out.println("              STRUK RESTO UT");
        System.out.println("========================================");
        for (int i = 0; i < daftarPesanan.size(); i++) {
            MenuItem item = daftarPesanan.get(i);
            int jumlah = jumlahPesanan.get(i);
            double totalItem = item.getHarga() * jumlah;

            System.out.printf("%-20s %2d x Rp%-10.0f Rp%.0f%n",
                    item.getNama(), jumlah, item.getHarga(), totalItem);
        }
        System.out.println("----------------------------------------");
        System.out.printf("Subtotal             : Rp%.0f%n", subtotal);

        if (diskon != null) {
            potongan = subtotal * diskon.getDiskon() / 100;
            System.out.printf("Diskon (%s - %.0f%%) : -Rp%.0f%n",
                    diskon.getNama(), diskon.getDiskon(), potongan);
        } else {
            System.out.println("Diskon               : Rp0");
        }

        System.out.printf("TOTAL BAYAR          : Rp%.0f%n", subtotal - potongan);
        System.out.println("========================================");
        System.out.println("          Terima kasih!");
        System.out.println("========================================");
    }

    public void simpanStruk(String namaFile, Menu menu) {
        if (isKosong()) {
            System.out.println("Belum ada pesanan yang dapat disimpan.");
            return;
        }

        double subtotal = hitungSubtotal();
        Diskon diskon = cariDiskon(menu);
        double potongan = (diskon == null) ? 0 : subtotal * diskon.getDiskon() / 100;

        try (PrintWriter writer = new PrintWriter(new FileWriter(namaFile, true))) {
            writer.println("========================================");
            writer.println("              STRUK RESTO UT");
            writer.println("========================================");
            for (int i = 0; i < daftarPesanan.size(); i++) {
                MenuItem item = daftarPesanan.get(i);
                int jumlah = jumlahPesanan.get(i);
                writer.printf("%s | %d x Rp%.0f = Rp%.0f%n",
                        item.getNama(), jumlah, item.getHarga(), item.getHarga() * jumlah);
            }
            writer.println("----------------------------------------");
            writer.printf("Subtotal: Rp%.0f%n", subtotal);
            if (diskon != null) {
                writer.printf("Diskon %s (%.0f%%): -Rp%.0f%n",
                        diskon.getNama(), diskon.getDiskon(), potongan);
            } else {
                writer.println("Diskon: Rp0");
            }
            writer.printf("TOTAL BAYAR: Rp%.0f%n", subtotal - potongan);
            writer.println("========================================");
            writer.println();
            System.out.println("Struk berhasil disimpan ke " + namaFile + ".");
        } catch (IOException e) {
            System.out.println("Gagal menyimpan struk: " + e.getMessage());
        }
    }

    public void tampilkanRiwayatStruk(String namaFile) {
        System.out.println("\n========== RIWAYAT STRUK ==========");
        try (BufferedReader reader = new BufferedReader(new FileReader(namaFile))) {
            String baris;
            while ((baris = reader.readLine()) != null) {
                System.out.println(baris);
            }
        } catch (IOException e) {
            System.out.println("Belum ada file riwayat struk atau file tidak dapat dibaca.");
        }
        System.out.println("===================================");
    }
}
